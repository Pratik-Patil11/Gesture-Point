import sys

def min_distance_traveled(passengers, vehicles):
    total_distance = 0
    allocated_vehicles = set()

    # Sort passengers lexicographically
    passengers = sorted(passengers.items())

    for passenger, (px, py) in passengers:
        min_distance = sys.maxsize
        allocated_vehicle = ""

        for vehicle, (vx, vy) in vehicles.items():
            if vehicle not in allocated_vehicles:
                distance = abs(px - vx) + abs(py - vy)

                if distance < min_distance or (distance == min_distance and vehicle < allocated_vehicle):
                    min_distance = distance
                    allocated_vehicle = vehicle

        total_distance += min_distance
        allocated_vehicles.add(allocated_vehicle)

    return total_distance

def main():
    N, M = map(int, input().split())

    passengers = {}
    vehicles = {}

    for _ in range(N):
        name, x, y = input().split()
        passengers[name] = (int(x), int(y))

    for _ in range(M):
        vehicle, x, y = input().split()
        vehicles[vehicle] = (int(x), int(y))

    result = min_distance_traveled(passengers, vehicles)
    print(result)

if __name__ == "__main__":
    main()
