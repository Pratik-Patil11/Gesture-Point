#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
#include <cctype>

// Function to simplify a digit to a single digit
int simplify_digit(int digit) {
    while (digit >= 10) {
        int digit_sum = 0;
        while (digit > 0) {
            digit_sum += digit % 10;
            digit /= 10;
        }
        digit = digit_sum;
    }
    return digit;
}

// Function to generate the password
void generate_password(double number, const std::string& name) {
    // Transform the number into scientific notation
    std::stringstream ss;
    ss << std::scientific << std::setprecision(10) << number;
    std::string scientific_notation = ss.str();

    // Simplify the exponent to a single digit
    int exponent = simplify_digit(std::stoi(scientific_notation.substr(scientific_notation.find('e') + 1)));

    // Generate S1 by concatenating the first three letters of each digit
    std::string s1 = "";
    for (char c : scientific_notation) {
        if (isdigit(c)) {
            s1 += '0' + (c - '0' + 1);
        }
        if (s1.size() == 3) break;
    }

    // Generate S2 by selecting letters at odd positions if the exponent is odd
    std::string s2 = "";
    if (exponent % 2 == 1) {
        for (size_t i = 0; i < name.size(); i += 2) {
            s2 += name[i];
        }
    } else {
        s2 = name;
    }

    // Print the formatted password
    std::cout << s1 << '@' << s2 << std::endl;
}

int main() {
    int t;
    std::cin >> t;

    for (int i = 0; i < t; i++) {
        double num;
        std::string name;
        std::cin >> num >> name;

        // Generate the password
        generate_password(num, name);
    }

    return 0;
}
