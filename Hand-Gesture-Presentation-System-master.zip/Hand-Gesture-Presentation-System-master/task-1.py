import math

# Function to simplify digits to a single digit
def simplify_to_single_digit(num):
    while num > 9:
        num = sum(int(digit) for digit in str(num))
    return num

# Function to convert a number to scientific notation and simplify the digits
def to_scientific_notation_and_simplify(number):
    number_str = '{:.10e}'.format(number)
    coefficient, exponent = map(str, number_str.split('e'))
    exponent = int(exponent)
    coefficient = int(coefficient.replace('.', ''))
    simplified_coefficient = simplify_to_single_digit(coefficient)
    simplified_exponent = simplify_to_single_digit(abs(exponent))
    return str(simplified_coefficient) + 'e' + str(simplified_exponent)

# Function to generate S1
def generate_S1(number):
    simplified_number = to_scientific_notation_and_simplify(number)
    words = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine']
    s1 = ''.join(words[int(digit)] if digit != 'e' else 'e' for digit in simplified_number if digit.isdigit())
    return s1[:3]

# Function to generate S2
def generate_S2(name, exponent):
    if exponent % 2 != 0:
        return ''.join(name[i] for i in range(len(name)) if i % 2 != 0)
    else:
        return ''

# Main function to process test cases
def process_test_cases(test_cases):
    passwords = []
    for test_case in test_cases:
        number, name = test_case
        if '.' in number:
            number = float(number)
        else:
            number = int(number)
        if name.islower():
            s1 = generate_S1(number)
            exponent = to_scientific_notation_and_simplify(number).split('e')[1]
            s2 = generate_S2(name, int(exponent))
            password = s1 + '@' + s2
            passwords.append(password)
        else:
            passwords.append("Invalid input")
    return passwords

# Example usage
test_cases = [(3.141592, 'tina'), (12345, 'eric')]
result = process_test_cases(test_cases)
for password in result:
    print(password)
