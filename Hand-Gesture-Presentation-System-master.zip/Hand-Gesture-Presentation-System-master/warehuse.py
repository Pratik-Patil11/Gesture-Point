def min_vehicles_needed(weights, max_limit):
    weights.sort()  # Sort the weights in non-decreasing order
    left, right = 0, len(weights) - 1  # Pointers for the two ends of the sorted array
    vehicles_count = 0  # Count of vehicles

    while left <= right:
        # Check if the sum of weights at the current pointers is less than or equal to max_limit
        if weights[left] + weights[right] <= max_limit:
            left += 1
        right -= 1

        vehicles_count += 1  # Increment the count of vehicles

    return vehicles_count

# Input
weights = list(map(int, input().split()))
max_limit = int(input())

# Output
result = min_vehicles_needed(weights, max_limit)
print(result)
