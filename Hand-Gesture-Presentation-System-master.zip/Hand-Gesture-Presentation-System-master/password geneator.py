def simplify_digit(digit):
    # Reduce a number to a single digit
    while digit >= 10:
        digit_sum = sum(int(d) for d in str(digit))
        digit = digit_sum
    return digit

def generate_password(number, name):
    # Check if the name contains only lowercase letters
    if not name.islower():
        return "Invalid input"

    # Transform the number into scientific notation
    scientific_notation = "{:e}".format(number)

    # Simplify the exponent to a single digit
    exponent = simplify_digit(int(scientific_notation.split('e')[1]))

    # Generate S1 by concatenating the first three letters of each digit
    s1 = ''.join([str(ord(c) - ord('0') + 1) for c in scientific_notation if c.isdigit()][:3])

    # Generate S2 by selecting letters at odd positions if the exponent is odd
    s2 = ''.join([name[i-1] for i in range(1, len(name)+1, 2)]) if exponent % 2 == 1 else ""

    # Return the formatted password
    return f"{s1}@{s2}"

# Input handling
t = int(input())
for _ in range(t):
    num, person_name = input().split()
    try:
        num = float(num)
        password = generate_password(num, person_name)
        print(password)
    except ValueError:
        print("Invalid input")
